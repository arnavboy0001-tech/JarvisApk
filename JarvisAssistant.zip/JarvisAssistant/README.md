# Jarvis — a JARVIS/EDITH-style Android assistant

A floating orb that sits on top of every app (and the home screen). Tap it to
type or speak; it answers out loud and can act on your phone — open apps, tap
things, scroll, go back/home, read what's on screen — using Android's
Accessibility API and Claude's tool use.

## Read this first — what's actually inside

- **The floating orb works over any app and the home screen.** That part is
  full JARVIS-style, and it's the reliable way to summon Jarvis from anywhere.
- **It is not registered as Android's system Assistant** (the thing you'd
  normally trigger with a long-press of the home button). That requires
  building a `VoiceInteractionService`, which is roughly its own app's worth
  of extra work — a good v2 if you want to take this further.
- **The brain is Claude**, called with your own Anthropic API key. You're
  billed by Anthropic directly for what you use — there's no key baked into
  the app, and there can't be, since you own this build.
- **No wake word yet** ("Hey Jarvis") — you open the panel with a tap on the
  orb or its in-panel mic button, not a spoken trigger phrase.

## One-time setup

1. Install **Android Studio** if you don't already have it.
2. Unzip this project, then in Android Studio: **File → Open**, and select
   the `JarvisAssistant` folder.
3. This project ships the Gradle build scripts but not the Gradle wrapper's
   binary jar (not something that can be handwritten). Android Studio will
   offer to generate the wrapper the first time it opens the project —
   accept that, then let Gradle sync finish. It targets **Gradle 8.9 /
   Android Gradle Plugin 8.7.2 / Kotlin 2.0.21 / compileSdk & targetSdk 35**,
   which recent Android Studio versions handle natively.
4. Connect a phone (USB debugging on) or start an emulator, then press
   **Run** ▶.

## Using the app

1. Paste an Anthropic API key (from console.anthropic.com) and tap
   **Save key**.
2. Tap **Grant** next to each of the three permissions and follow the system
   screens:
   - **Floating orb** → "display over other apps" for Jarvis
   - **App control** → turn Jarvis on in Accessibility settings
   - **Microphone** → the normal Android permission dialog
   Come back to the app after each one; the ✕/✓ marks update automatically.
3. Tap **Start Jarvis**. A small orb appears — drag it anywhere on screen.
   Tap it to open the panel, then type or tap the mic button and talk.
   Tap the notification's **Stop Jarvis** action (or the button in-app) to
   turn it off.

## If the orb disappears after a while

That's almost always the phone's battery manager killing background apps —
very common on Xiaomi/MIUI, Vivo, Oppo, and OnePlus. Starting Jarvis also
triggers a one-time system prompt asking to exempt it from battery
optimization — accept that. On those OEM skins, also check Settings → Apps →
Jarvis for an **Autostart**/**Auto-launch** toggle and turn it on.

## Customizing

- **Rename the app / package**: in Android Studio, right-click the
  `com.jarvis.assistant` package → Refactor → Rename.
- **Switch models**: edit `Prefs.DEFAULT_MODEL` in `Prefs.kt` — e.g. to
  `claude-haiku-4-5-20251001` for faster, cheaper replies, or
  `claude-opus-5-5` for the most capable one.
- **Add more actions**: extend the tool list in `JarvisTools.kt` and give it
  a matching method in `JarvisAccessibilityService.kt`.
- **Look**: colors live in `res/values/colors.xml`; the orb/app icon is
  `res/drawable/ic_launcher_foreground.xml` (a vector, easy to restyle).

## Known limits

- Tapping by on-screen text works well in most apps but isn't perfect — some
  apps draw custom UI that doesn't expose readable text to accessibility
  services.
- No offline mode — every request needs internet and calls the Claude API,
  which costs a small amount per request on your key.
- The keyboard/IME behavior for the floating panel's text field can vary a
  little by device — if typing feels off on yours, that's the first thing to
  tweak (see `OverlayService.showPanel()`).
