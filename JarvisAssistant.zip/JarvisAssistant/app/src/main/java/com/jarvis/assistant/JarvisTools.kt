package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject

/**
 * The set of actions Jarvis can take on the phone, described as Claude
 * "tools" (https://docs.claude.com/en/docs/agents-and-tools/tool-use).
 * Add a new capability by adding both a definition here and a matching
 * method on [JarvisAccessibilityService].
 */
object JarvisTools {

    fun definitions(): JSONArray {
        val tools = JSONArray()

        tools.put(tool(
            "open_app",
            "Open an app on the phone by its everyday name, e.g. 'WhatsApp' or 'Chrome'.",
            schema("app_name")
        ))
        tools.put(tool("go_home", "Go to the phone's home screen.", schema()))
        tools.put(tool("go_back", "Press the system back button.", schema()))
        tools.put(tool(
            "tap_text",
            "Tap the on-screen element whose visible text or label matches this.",
            schema("text")
        ))
        tools.put(tool(
            "scroll",
            "Scroll the current screen. direction must be 'up' or 'down'.",
            schema("direction")
        ))
        tools.put(tool(
            "read_screen",
            "Re-read the visible text currently on screen right now.",
            schema()
        ))

        return tools
    }

    /** Runs one tool_use block and returns the matching tool_result block. */
    fun execute(toolUse: JSONObject): JSONObject {
        val id = toolUse.optString("id")
        val name = toolUse.optString("name")
        val input = toolUse.optJSONObject("input") ?: JSONObject()
        val service = JarvisAccessibilityService.instance

        val resultText: String = if (service == null) {
            "Jarvis's accessibility service isn't connected, so it can't control " +
                "the phone right now. Ask the user to enable it in Jarvis's settings."
        } else {
            try {
                when (name) {
                    "open_app" -> service.openApp(input.optString("app_name"))
                    "go_home" -> service.goHome()
                    "go_back" -> service.goBack()
                    "tap_text" -> service.tapByText(input.optString("text"))
                    "scroll" -> service.scroll(input.optString("direction", "down"))
                    "read_screen" -> service.readScreenText()
                    else -> "Unknown action: $name"
                }
            } catch (e: Exception) {
                "Action failed: ${e.message}"
            }
        }

        return JSONObject()
            .put("type", "tool_result")
            .put("tool_use_id", id)
            .put("content", resultText)
    }

    private fun tool(name: String, description: String, inputSchema: JSONObject): JSONObject {
        return JSONObject()
            .put("name", name)
            .put("description", description)
            .put("input_schema", inputSchema)
    }

    private fun schema(vararg stringProps: String): JSONObject {
        val properties = JSONObject()
        val required = JSONArray()
        for (propName in stringProps) {
            properties.put(propName, JSONObject().put("type", "string"))
            required.put(propName)
        }
        return JSONObject()
            .put("type", "object")
            .put("properties", properties)
            .put("required", required)
    }
}
