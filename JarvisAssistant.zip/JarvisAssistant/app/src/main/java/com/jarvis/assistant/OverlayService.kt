package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelShown = false

    private lateinit var voice: VoiceEngine
    private val history = mutableListOf<JSONObject>()

    override fun onCreate() {
        super.onCreate()
        Prefs.setRunning(this, true)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        voice = VoiceEngine(this)
        voice.init()
        startForeground(NOTIF_ID, buildNotification())
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Prefs.setRunning(this, false)
        removePanel()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        voice.release()
        super.onDestroy()
    }

    // ---------- Floating bubble ----------

    private fun addBubble() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 24
        params.y = 300
        bubbleParams = params

        val view = LayoutInflater.from(this).inflate(R.layout.view_bubble, null)
        bubbleView = view

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) dragging = true
                    if (dragging) {
                        params.x = startX + dx
                        params.y = startY + dy
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) togglePanel()
                    true
                }
                else -> false
            }
        }

        runCatching { windowManager.addView(view, params) }
    }

    private fun togglePanel() {
        if (panelShown) removePanel() else showPanel()
    }

    // ---------- Expanded panel ----------

    private fun showPanel() {
        if (panelView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.view_panel, null)
        panelView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 24
        params.y = (bubbleParams?.y ?: 300) + 160

        val input = view.findViewById<EditText>(R.id.panelInput)
        val micButton = view.findViewById<ImageButton>(R.id.panelMicButton)
        val status = view.findViewById<TextView>(R.id.panelStatus)
        val transcript = view.findViewById<TextView>(R.id.panelTranscript)

        input.setOnEditorActionListener { _, _, _ ->
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserUtterance(text, status, transcript)
            }
            true
        }

        micButton.setOnClickListener {
            status.text = getString(R.string.status_listening)
            voice.listen(
                onResult = { text -> handleUserUtterance(text, status, transcript) },
                onError = { err -> status.text = err }
            )
        }

        runCatching { windowManager.addView(view, params) }
        panelShown = true
    }

    private fun removePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        panelShown = false
    }

    private fun handleUserUtterance(text: String, status: TextView, transcript: TextView) {
        transcript.append("\n\nYou: $text")
        status.text = getString(R.string.status_thinking)

        history.add(JSONObject().put("role", "user").put("content", text))
        while (history.size > 20) history.removeAt(0)

        val screenText = JarvisAccessibilityService.instance?.readScreenText()

        ClaudeClient.send(this, history.toList(), screenText, object : ClaudeClient.ResultCallback {
            override fun onResult(reply: String) {
                history.add(JSONObject().put("role", "assistant").put("content", reply))
                runOnUi {
                    status.text = getString(R.string.status_ready)
                    transcript.append("\n\nJarvis: $reply")
                    voice.speak(reply)
                }
            }

            override fun onError(message: String) {
                runOnUi {
                    status.text = getString(R.string.status_ready)
                    transcript.append("\n\nJarvis: $message")
                }
            }
        })
    }

    private fun runOnUi(action: () -> Unit) {
        Handler(mainLooper).post(action)
    }

    // ---------- Foreground notification ----------

    private fun buildNotification(): android.app.Notification {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)

        val stopIntent = Intent(this, OverlayService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val openPending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_jarvis_orb)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(openPending)
            .addAction(0, getString(R.string.stop_jarvis), stopPending)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "jarvis_running"
        private const val NOTIF_ID = 42
        const val ACTION_STOP = "com.jarvis.assistant.ACTION_STOP"
    }
}
