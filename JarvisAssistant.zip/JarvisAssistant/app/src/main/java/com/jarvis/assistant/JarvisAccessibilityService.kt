package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * The user must turn this on manually under Settings > Accessibility (Android
 * requires that for any service with this level of access). Once on, Jarvis
 * can see screen text and act on the user's behalf when asked.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Jarvis pulls screen state on demand (readScreenText) rather than
        // streaming every event, so nothing to do here.
    }

    override fun onInterrupt() {}

    fun readScreenText(): String {
        val root = rootInActiveWindow ?: return "Nothing readable is on screen right now."
        val chunks = mutableListOf<String>()
        collectText(root, chunks)
        root.recycle()
        return if (chunks.isEmpty()) "The screen has no readable text right now."
        else chunks.joinToString(" · ").take(4000)
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        val text = node.text?.toString()?.trim()
        if (!text.isNullOrEmpty()) out.add(text)
        val desc = node.contentDescription?.toString()?.trim()
        if (!desc.isNullOrEmpty() && desc != text) out.add(desc)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, out)
            child.recycle()
        }
    }

    fun tapByText(target: String): String {
        val root = rootInActiveWindow ?: return "Nothing on screen to tap."
        val node = findNodeByText(root, target)
        return if (node != null) {
            val clicked = clickNode(node)
            node.recycle()
            root.recycle()
            if (clicked) "Tapped \"$target\"." else "Found \"$target\" but couldn't tap it."
        } else {
            root.recycle()
            "Couldn't find anything on screen matching \"$target\"."
        }
    }

    private fun findNodeByText(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        if (text.contains(target, ignoreCase = true) || desc.contains(target, ignoreCase = true)) {
            return AccessibilityNodeInfo.obtain(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByText(child, target)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                if (current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            current = current.parent
        }
        // Fall back to a raw tap gesture at the node's centre.
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return tapAt(rect.centerX().toFloat(), rect.centerY().toFloat())
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun scroll(direction: String): String {
        val root = rootInActiveWindow
        val scrollable = root?.let { findScrollable(it) }
        val action = if (direction == "up")
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        else
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD

        val done = scrollable?.performAction(action) ?: false
        scrollable?.recycle()
        root?.recycle()
        return if (done) "Scrolled $direction." else "Nothing scrollable found on screen."
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    fun goHome(): String {
        performGlobalAction(GLOBAL_ACTION_HOME)
        return "Went to the home screen."
    }

    fun goBack(): String {
        performGlobalAction(GLOBAL_ACTION_BACK)
        return "Pressed back."
    }

    fun openApp(appName: String): String {
        if (appName.isBlank()) return "No app name given."
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true)
        } ?: return "Couldn't find an app called \"$appName\"."

        val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return "\"$appName\" doesn't have a launchable screen."
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
        return "Opening ${pm.getApplicationLabel(match)}."
    }
}
