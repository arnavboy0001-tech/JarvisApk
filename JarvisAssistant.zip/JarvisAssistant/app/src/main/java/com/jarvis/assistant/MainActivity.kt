package com.jarvis.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var apiKeyInput: EditText
    private lateinit var overlayStatus: TextView
    private lateinit var accessibilityStatus: TextView
    private lateinit var micStatus: TextView
    private lateinit var startButton: Button
    private var jarvisRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiKeyInput = findViewById(R.id.apiKeyInput)
        overlayStatus = findViewById(R.id.overlayStatus)
        accessibilityStatus = findViewById(R.id.accessibilityStatus)
        micStatus = findViewById(R.id.micStatus)
        startButton = findViewById(R.id.startButton)
        jarvisRunning = Prefs.isRunning(this)

        Prefs.getApiKey(this)?.let { apiKeyInput.setText(it) }

        findViewById<Button>(R.id.saveKeyButton).setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "Paste your Anthropic API key first.", Toast.LENGTH_SHORT).show()
            } else {
                Prefs.saveApiKey(this, key)
                Toast.makeText(this, "Key saved.", Toast.LENGTH_SHORT).show()
                refreshStatuses()
            }
        }

        findViewById<Button>(R.id.overlayButton).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find Jarvis in the list and turn it on.", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.micButton).setOnClickListener {
            val perms = mutableListOf(android.Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                // Needed on Android 13+ for the running-service notification to show.
                perms.add(android.Manifest.permission.POST_NOTIFICATIONS)
            }
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), REQUEST_MIC)
        }

        startButton.setOnClickListener {
            if (jarvisRunning) stopJarvis() else startJarvis()
        }
    }

    override fun onResume() {
        super.onResume()
        jarvisRunning = Prefs.isRunning(this)
        refreshStatuses()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatuses()
    }

    private fun refreshStatuses() {
        val overlayGranted = Settings.canDrawOverlays(this)
        val accessibilityGranted = isAccessibilityServiceEnabled()
        val micGranted = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        setStatus(overlayStatus, overlayGranted)
        setStatus(accessibilityStatus, accessibilityGranted)
        setStatus(micStatus, micGranted)

        val hasKey = !Prefs.getApiKey(this).isNullOrBlank()
        val allReady = overlayGranted && accessibilityGranted && micGranted && hasKey
        startButton.isEnabled = allReady || jarvisRunning
        startButton.alpha = if (startButton.isEnabled) 1f else 0.4f
        startButton.text = getString(if (jarvisRunning) R.string.stop_jarvis else R.string.start_jarvis)
    }

    private fun setStatus(view: TextView, granted: Boolean) {
        view.text = if (granted) "✓" else "✕"
        view.setTextColor(
            ContextCompat.getColor(this, if (granted) R.color.jarvis_accent else R.color.jarvis_error)
        )
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = ComponentName(this, JarvisAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(":").any { it.equals(expected, ignoreCase = true) }
    }

    private fun startJarvis() {
        startForegroundService(Intent(this, OverlayService::class.java))
        jarvisRunning = true
        requestIgnoreBatteryOptimizations()
        refreshStatuses()
        Toast.makeText(this, "Jarvis is running — look for the orb.", Toast.LENGTH_SHORT).show()
    }

    private fun stopJarvis() {
        stopService(Intent(this, OverlayService::class.java))
        jarvisRunning = false
        refreshStatuses()
    }

    /** Best-effort: many OEMs (Xiaomi, Vivo, Oppo, OnePlus) kill background
     * services unless the app is exempted from battery optimization. */
    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            runCatching { startActivity(intent) }
        }
    }

    companion object {
        private const val REQUEST_MIC = 1001
    }
}
