package com.jarvis.assistant

import android.content.Context

/**
 * Plain (non-encrypted) SharedPreferences, sandboxed to this app by Android
 * like any other app's private storage. Good enough for a personal build —
 * if you want extra hardening, swap this for androidx.security's
 * EncryptedSharedPreferences.
 */
object Prefs {

    private const val FILE_NAME = "jarvis_prefs"
    private const val KEY_API_KEY = "anthropic_api_key"
    private const val KEY_MODEL = "claude_model"
    private const val KEY_RUNNING = "jarvis_running"

    /** Fast and inexpensive; swap for "claude-opus-5-5" if you want more capability. */
    const val DEFAULT_MODEL = "claude-sonnet-5"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun saveApiKey(context: Context, key: String) {
        prefs(context).edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun getApiKey(context: Context): String? =
        prefs(context).getString(KEY_API_KEY, null)

    fun getModel(context: Context): String =
        prefs(context).getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL

    fun setModel(context: Context, model: String) {
        prefs(context).edit().putString(KEY_MODEL, model).apply()
    }

    fun setRunning(context: Context, running: Boolean) {
        prefs(context).edit().putBoolean(KEY_RUNNING, running).apply()
    }

    fun isRunning(context: Context): Boolean =
        prefs(context).getBoolean(KEY_RUNNING, false)
}
