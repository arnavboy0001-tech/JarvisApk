package com.jarvis.assistant

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to https://api.anthropic.com/v1/messages using the key the user
 * pasted into the app, and drives Claude's tool-use loop so Jarvis can act
 * on the phone (see JarvisTools) before giving its final spoken answer.
 */
object ClaudeClient {

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val API_VERSION = "2023-06-01"
    private const val MAX_TOOL_ROUNDS = 3

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val SYSTEM_PROMPT = """
        You are Jarvis, a concise voice-first assistant running on the user's
        Android phone. Keep spoken replies short and natural, like a real
        assistant talking out loud - a sentence or two unless the user clearly
        wants more detail. You may see a snapshot of the text on the user's
        current screen below, and you can act on the phone with the available
        tools (open an app, go home, go back, tap something by its visible
        label, scroll, or re-read the current screen). Only use a tool when
        the user is clearly asking for an action; otherwise just answer.
    """.trimIndent()

    interface ResultCallback {
        fun onResult(text: String)
        fun onError(message: String)
    }

    fun send(
        context: Context,
        history: List<JSONObject>,
        screenText: String?,
        callback: ResultCallback
    ) {
        val apiKey = Prefs.getApiKey(context)
        if (apiKey.isNullOrBlank()) {
            callback.onError("No Anthropic API key set yet. Open Jarvis and add one.")
            return
        }

        val messages = JSONArray()
        for (message in history) messages.put(message)

        if (!screenText.isNullOrBlank()) {
            messages.put(
                JSONObject()
                    .put("role", "user")
                    .put("content", "[Current screen text]\n$screenText")
            )
        }

        callWithTools(apiKey, Prefs.getModel(context), messages, callback, MAX_TOOL_ROUNDS)
    }

    private fun callWithTools(
        apiKey: String,
        model: String,
        messages: JSONArray,
        callback: ResultCallback,
        roundsLeft: Int
    ) {
        val requestBody = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", SYSTEM_PROMPT)
            .put("messages", messages)
            .put("tools", JarvisTools.definitions())

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", API_VERSION)
            .addHeader("content-type", "application/json")
            .post(requestBody.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback.onError("Network error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    val bodyStr = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        callback.onError(describeError(bodyStr, resp.code))
                        return
                    }
                    handleResponse(apiKey, model, messages, bodyStr, callback, roundsLeft)
                }
            }
        })
    }

    private fun handleResponse(
        apiKey: String,
        model: String,
        messages: JSONArray,
        bodyStr: String,
        callback: ResultCallback,
        roundsLeft: Int
    ) {
        try {
            val json = JSONObject(bodyStr)
            val content = json.optJSONArray("content") ?: JSONArray()

            val spokenText = StringBuilder()
            val toolUses = mutableListOf<JSONObject>()

            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                when (block.optString("type")) {
                    "text" -> spokenText.append(block.optString("text"))
                    "tool_use" -> toolUses.add(block)
                }
            }

            if (toolUses.isEmpty() || roundsLeft <= 0) {
                callback.onResult(spokenText.toString().ifBlank { "Done." })
                return
            }

            // Record the assistant's turn (including its tool_use blocks),
            // then feed back one tool_result per call and ask again.
            messages.put(JSONObject().put("role", "assistant").put("content", content))

            val resultsContent = JSONArray()
            for (toolUse in toolUses) {
                resultsContent.put(JarvisTools.execute(toolUse))
            }
            messages.put(JSONObject().put("role", "user").put("content", resultsContent))

            callWithTools(apiKey, model, messages, callback, roundsLeft - 1)
        } catch (e: Exception) {
            callback.onError("Couldn't read Claude's reply: ${e.message}")
        }
    }

    private fun describeError(bodyStr: String, code: Int): String {
        return try {
            val err = JSONObject(bodyStr).optJSONObject("error")
            "Anthropic API error ($code): ${err?.optString("message") ?: bodyStr}"
        } catch (e: Exception) {
            "Anthropic API error ($code)"
        }
    }
}
