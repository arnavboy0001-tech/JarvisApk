# Add project specific ProGuard rules here.
# Minification is off by default (see app/build.gradle.kts), so this file
# only matters once you turn isMinifyEnabled on for release builds.
